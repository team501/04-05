let backendHost;
const hostname = window && window.location && window.location.hostname;

if (hostname !== 'localhost') {
		backendHost = '192.168.13.195';
} else if (hostname === 'localhost') {
		backendHost = 'localhost';
} else {
		backendHost = 'localhost';
}

export const graphQlURLPrd = 'http://'+ backendHost + ':8088/graphql';
export const wCSURL = 'http://'+ backendHost + ':8082/api';