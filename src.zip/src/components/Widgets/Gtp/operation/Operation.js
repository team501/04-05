import React, { Component } from 'react';



import Pbar from './Pbar.js';
import ArcProgressbar from '../arc/SegmentedArcProgressBar/ArcProgressbar';
import 'react-circular-progressbar/dist/styles.css';

// Import custom examples
import SegmentedArcProgressbar from '../arc/SegmentedArcProgressbar';

class OverallWorkMonitor extends Component {
    render(){
	const percentage = 35;
      return(
        <div className="app-horizontal collapsed-sidebar">
        <div className="app-container">
            <div className="rct-page-wrapper">
                <div className="rct-app-content">
                    <div className="app-header">
                      <div className="operation_bg overall-work-monitor">
							<div className="title">Operations</div>
							<div class="row row-no-margin">
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 leftAlign"> 
								</div>
								<div className="col-sm-5 col-md-5 col-lg-5 col-xl-5 leftAlign"> 
								</div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 leftAlign opHeadertext"> Total
								</div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 leftAlign center opHeadertext"> Producity
								</div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 leftAlign opHeadertext"> Bin Status
								</div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 leftAlign opHeadertext"> Others
								</div>
								
								
							</div>
							
							<div className="row row-no-margin opration-radius">
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 leftAlign station-status-textblack text-middle alignLeft"> Picking
								</div>
								<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 leftAlign"> 
									<div className="row row-no-margin">
									<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 leftAlign">
										<div className="opcontainersubtext">Progress</div>
										<div className="opsmalltext"><i>(In Units)</i></div>
									<div className="opcontainersubtext">Time</div>
										<div className="opsmalltext"><i>(hh:mm:ss)</i></div>
									</div>
									<div className="col-sm-8 col-md-8 col-lg-8 col-xl-8 leftAlign"> <Pbar/></div>
								
									</div>
								</div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 leftAlign"> 
									<div className="station-status-textblack margin17">26000</div>
									<div className="station-status-textblack margin28">99:99:99</div>
								</div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2"> 
									<div style={{paddingLeft: '25px'}}>
										<div style={{ width: '80px', height: '80px'}}>
											<SegmentedArcProgressbar percentage={percentage}  segments={20} textColor={"#000000"}/>
											<div className="prodLabel"><b>9999</b>/9999</div>
											<div className="prodSubLabel"><i>(For Hour)</i></div>
										</div>		
									</div>
								</div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 alignBinStatus "> 
									<div className="station-status-textblack margin17">9999</div>
									<div className="station-status-activetext">Processed</div>
									<div className="station-status-textblack margin10">999<span className="pRateLabel"><i>/Hr</i></span></div>
									<div className="station-status-activetext noWrap">Process Rate</div>
								</div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 alignOthers">
									<div className="station-status-textblack">999</div>
									<div className="station-status-activetext noWrap">Active Stations</div>
									<div className="station-status-textblack opblack">&#x2BC6;00:00:00<span className="pRateLabel"><i>/Hr</i></span></div>
									<div className="station-status-activetext noWrap">Dwell Time</div>
								</div>								
							</div>
							
							<div className="row row-no-margin opration-radius">
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 leftAlign station-status-textblack text-middle alignLeft"> Consolidation
								</div>
								<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 leftAlign"> 
									<div className="row row-no-margin">
									<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 leftAlign">
										<div className="opcontainersubtext">Progress</div>
										<div className="opsmalltext"><i>(In Units)</i></div>
									<div className="opcontainersubtext">Time</div>
										<div className="opsmalltext"><i>(hh:mm:ss)</i></div>
									</div>
									<div className="col-sm-8 col-md-8 col-lg-8 col-xl-8 leftAlign"> <Pbar/></div>
								
									</div>
								</div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 leftAlign"> 
									<div className="station-status-textblack margin17">26000</div>
									<div className="station-status-textblack margin28">99:99:99</div>
								</div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2"> 
									<div style={{paddingLeft: '25px'}}>
										<div style={{ width: '80px', height: '80px'}}>
											<SegmentedArcProgressbar percentage={percentage}  segments={20} textColor={"#000000"}/>
											<div className="prodLabel"><b>9999</b>/9999</div>
											<div className="prodSubLabel"><i>(For Hour)</i></div>
										</div>		
									</div>
								</div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 alignBinStatus "> 
									<div className="station-status-textblack margin17">9999</div>
									<div className="station-status-activetext">Processed</div>
									<div className="station-status-textblack margin10">999<span className="pRateLabel"><i>/Hr</i></span></div>
									<div className="station-status-activetext noWrap">Process Rate</div>
								</div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 alignOthers">
									<div className="station-status-textblack margin17">999</div>
									<div className="station-status-activetext noWrap">Active Stations</div>
									<div className="station-status-textblack opblack">&#x2BC6;00:00:00<span className="pRateLabel"><i>/Hr</i></span></div>
									<div className="station-status-activetext noWrap">Dwell Time</div>
								</div>								
							</div>
							
							
							<div className="row row-no-margin opration-radius">
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 leftAlign station-status-textblack text-middle alignLeft"> Decanting
								</div>
								<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 leftAlign"> 
									<div className="row row-no-margin">
									<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 leftAlign">
										<div className="opcontainersubtext">Progress</div>
										<div className="opsmalltext"><i>(In Units)</i></div>
									<div className="opcontainersubtext">Time</div>
										<div className="opsmalltext"><i>(hh:mm:ss)</i></div>
									</div>
									<div className="col-sm-8 col-md-8 col-lg-8 col-xl-8 leftAlign"> <Pbar/></div>
								
									</div>
								</div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 leftAlign"> 
									<div className="station-status-textblack margin17">26000</div>
									<div className="station-status-textblack margin28">99:99:99</div>
								</div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2"> 
									<div style={{paddingLeft: '25px'}}>
										<div style={{ width: '80px', height: '80px'}}>
											<SegmentedArcProgressbar percentage={percentage}  segments={20} textColor={"#000000"}/>
											<div className="prodLabel"><b>9999</b>/9999</div>
											<div className="prodSubLabel"><i>(For Hour)</i></div>
										</div>		
									</div>
								</div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 alignBinStatus "> 
									<div className="station-status-textblack margin17">9999</div>
									<div className="station-status-activetext">Processed</div>
									<div className="station-status-textblack margin10">999<span className="pRateLabel"><i>/Hr</i></span></div>
									<div className="station-status-activetext noWrap">Process Rate</div>
								</div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 leftAlign">
									<div className="station-status-textblack margin17">999</div>
									<div className="station-status-activetext noWrap">Active Stations</div>
									<div className="station-status-textblack opblack">&#x2BC6;00:00:00<span className="pRateLabel"><i>/Hr</i></span></div>
									<div className="station-status-activetext noWrap">Dwell Time</div>
								</div>								
							</div>
							
							
							<div className="row row-no-margin opration-radius">
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 leftAlign station-status-textblack text-middle alignLeft"> Cycle Count
								</div>
								<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 leftAlign"> 
									<div className="row row-no-margin">
									<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 leftAlign">
										<div className="opcontainersubtext">Progress</div>
										<div className="opsmalltext"><i>(In Units)</i></div>
									<div className="opcontainersubtext">Time</div>
										<div className="opsmalltext"><i>(hh:mm:ss)</i></div>
									</div>
									<div className="col-sm-8 col-md-8 col-lg-8 col-xl-8 leftAlign"> <Pbar/></div>
								
									</div>
								</div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 leftAlign"> 
									<div className="station-status-textblack margin17">26000</div>
									<div className="station-status-textblack margin28">99:99:99</div>
								</div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2"> 
									<div style={{paddingLeft: '25px'}}>
										<div style={{ width: '80px', height: '80px'}}>
											<SegmentedArcProgressbar percentage={percentage}  segments={20} textColor={"#000000"}/>
											<div className="prodLabel"><b>9999</b>/9999</div>
											<div className="prodSubLabel"><i>(For Hour)</i></div>
										</div>		
									</div>
								</div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 alignBinStatus "> 
									<div className="station-status-textblack margin17">9999</div>
									<div className="station-status-activetext">Processed</div>
									<div className="station-status-textblack margin10">999<span className="pRateLabel"><i>/Hr</i></span></div>
									<div className="station-status-activetext noWrap">Process Rate</div>
								</div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 leftAlign">
									<div className="station-status-textblack margin17">999</div>
									<div className="station-status-activetext noWrap">Active Stations</div>
									<div className="station-status-textblack opblack">&#x2BC6;00:00:00<span className="pRateLabel"><i>/Hr</i></span></div>
									<div className="station-status-activetext noWrap">Dwell Time</div>
								</div>								
							</div>
							
							
							
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
                      
      );
    }
  }
export default OverallWorkMonitor;
